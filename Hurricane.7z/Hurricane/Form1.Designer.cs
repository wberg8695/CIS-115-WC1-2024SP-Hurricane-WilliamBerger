﻿namespace Hurricane
{
    partial class Hurricane
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            calculateButton = new Button();
            inputBox = new TextBox();
            inputLabel = new Label();
            outputBox = new Label();
            SuspendLayout();
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(90, 125);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(94, 29);
            calculateButton.TabIndex = 0;
            calculateButton.Text = "Calculate";
            calculateButton.UseVisualStyleBackColor = true;
            calculateButton.Click += CalculateButton_Click;
            // 
            // inputBox
            // 
            inputBox.Location = new Point(290, 60);
            inputBox.Name = "inputBox";
            inputBox.Size = new Size(125, 27);
            inputBox.TabIndex = 1;
            // 
            // inputLabel
            // 
            inputLabel.AutoSize = true;
            inputLabel.Location = new Point(50, 60);
            inputLabel.Name = "inputLabel";
            inputLabel.Size = new Size(180, 20);
            inputLabel.TabIndex = 2;
            inputLabel.Text = "Enter Wind Speed in MPH";
            // 
            // outputBox
            // 
            outputBox.BorderStyle = BorderStyle.Fixed3D;
            outputBox.Location = new Point(290, 125);
            outputBox.Name = "outputBox";
            outputBox.Size = new Size(125, 27);
            outputBox.TabIndex = 3;
            // 
            // Hurricane
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(482, 228);
            Controls.Add(outputBox);
            Controls.Add(inputLabel);
            Controls.Add(inputBox);
            Controls.Add(calculateButton);
            Name = "Hurricane";
            Text = "Hurricane Category Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button calculateButton;
        private TextBox inputBox;
        private Label inputLabel;
        private Label outputBox;
    }
}
