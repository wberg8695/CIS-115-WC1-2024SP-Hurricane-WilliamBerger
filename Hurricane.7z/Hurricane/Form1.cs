namespace Hurricane
{
    public partial class Hurricane : Form
    {
        public Hurricane()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            string input, output;
            input = inputBox.Text;
            int mph;
            mph = Convert.ToInt32(input);
            if (mph >= 157)
                output = "Category 5";
            else
                if (mph >= 130)
                output = "Category 4";
            else
                if (mph >= 111)
                output = "Category 3";
            else
                if (mph >= 96)
                output = "Category 2";
            else
                if (mph >= 74)
                output = "Category 1";
            else
                output = "Not a hurricane";
            outputBox.Text = output;
        }
    }
}
